# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module to School Management System
# ----------------------------------------------------------

from . import school
from . import student
from . import teacher
from . import parent
from . import res_users
